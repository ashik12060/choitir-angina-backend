const express = require('express');
const { createShop, getShops, assignProductToShop, getShopProducts } = require('../controllers/shopController');
// const { createShop, getShops } = require');
const router = express.Router();

router.post('/shop/create', createShop);
router.get('/shops/show', getShops);
router.post("/shops/:shopId/assign-product", assignProductToShop);
router.get("/shops/:shopId/products", getShopProducts); 

module.exports = router;
